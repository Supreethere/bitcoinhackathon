import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/layout/Layout';
import Dashboard from './pages/Dashboard';
import BlockExplorer from './pages/BlockExplorer';
import Transactions from './pages/Transactions';
import Analytics from './pages/Analytics';
import Settings from './pages/Settings';
import Learn from './pages/Learn';
import TransactionDetails from './pages/TransactionDetails';
import BlockDetails from './pages/BlockDetails';
import { useEffect } from 'react';
import { useAppStore } from './stores/appStore';
import { useNetworkStatus } from './hooks/useNetworkStatus';

function App() {
  const { checkInitialNetwork } = useAppStore();
  const { startMonitoring } = useNetworkStatus();

  useEffect(() => {
    // Initialize the app
    checkInitialNetwork();
    startMonitoring();
  }, [checkInitialNetwork, startMonitoring]);

  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Dashboard />} />
        <Route path="explorer" element={<BlockExplorer />} />
        <Route path="explorer/block/:blockId" element={<BlockDetails />} />
        <Route path="transactions" element={<Transactions />} />
        <Route path="transactions/:txId" element={<TransactionDetails />} />
        <Route path="analytics" element={<Analytics />} />
        <Route path="settings" element={<Settings />} />
        <Route path="learn" element={<Learn />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}

export default App;
import { useState, useEffect, useCallback } from 'react';
import { useAppStore } from '../stores/appStore';

export const useNetworkStatus = () => {
  const { setIsConnected, isConnected } = useAppStore();
  const [lastPingTime, setLastPingTime] = useState<number | null>(null);

  // Check connection status
  const checkConnection = useCallback(() => {
    const status = navigator.onLine;
    setIsConnected(status);
    setLastPingTime(status ? Date.now() : null);
    return status;
  }, [setIsConnected]);

  // Start monitoring
  const startMonitoring = useCallback(() => {
    checkConnection();

    // Add event listeners for online/offline status
    window.addEventListener('online', () => setIsConnected(true));
    window.addEventListener('offline', () => setIsConnected(false));

    // Set up regular ping to check connection
    const intervalId = setInterval(() => {
      checkConnection();
    }, 30000); // Check every 30 seconds

    return () => {
      window.removeEventListener('online', () => setIsConnected(true));
      window.removeEventListener('offline', () => setIsConnected(false));
      clearInterval(intervalId);
    };
  }, [checkConnection, setIsConnected]);

  return {
    isConnected,
    lastPingTime,
    checkConnection,
    startMonitoring,
  };
};
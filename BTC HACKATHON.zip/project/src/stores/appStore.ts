import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { SidechainType } from '../types/sidechain';

interface NetworkSettings {
  apiEndpoint: string;
  websocketEndpoint: string;
  rpcEndpoint: string;
}

interface AppState {
  currentSidechain: SidechainType;
  isDarkMode: boolean;
  isConnected: boolean;
  refreshInterval: number;
  showTestnet: boolean;
  networkSettings: Record<SidechainType, NetworkSettings>;
  setCurrentSidechain: (sidechain: SidechainType) => void;
  setIsDarkMode: (isDarkMode: boolean) => void;
  setIsConnected: (isConnected: boolean) => void;
  setRefreshInterval: (interval: number) => void;
  setShowTestnet: (show: boolean) => void;
  updateNetworkSettings: (sidechain: SidechainType, settings: Partial<NetworkSettings>) => void;
  checkInitialNetwork: () => void;
}

// Default network settings
const defaultNetworkSettings: Record<SidechainType, NetworkSettings> = {
  thunder: {
    apiEndpoint: 'https://api.thunder.layertwolabs.com',
    websocketEndpoint: 'wss://ws.thunder.layertwolabs.com',
    rpcEndpoint: 'https://rpc.thunder.layertwolabs.com',
  },
  zside: {
    apiEndpoint: 'https://api.zside.layertwolabs.com',
    websocketEndpoint: 'wss://ws.zside.layertwolabs.com',
    rpcEndpoint: 'https://rpc.zside.layertwolabs.com',
  },
  bitnames: {
    apiEndpoint: 'https://api.bitnames.layertwolabs.com',
    websocketEndpoint: 'wss://ws.bitnames.layertwolabs.com',
    rpcEndpoint: 'https://rpc.bitnames.layertwolabs.com',
  },
};

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      currentSidechain: 'thunder',
      isDarkMode: true,
      isConnected: false,
      refreshInterval: 10000, // 10 seconds
      showTestnet: false,
      networkSettings: defaultNetworkSettings,
      
      setCurrentSidechain: (sidechain) => set({ currentSidechain: sidechain }),
      setIsDarkMode: (isDarkMode) => set({ isDarkMode }),
      setIsConnected: (isConnected) => set({ isConnected }),
      setRefreshInterval: (interval) => set({ refreshInterval: interval }),
      setShowTestnet: (show) => set({ showTestnet: show }),
      
      updateNetworkSettings: (sidechain, settings) => set((state) => ({
        networkSettings: {
          ...state.networkSettings,
          [sidechain]: {
            ...state.networkSettings[sidechain],
            ...settings,
          },
        },
      })),
      
      checkInitialNetwork: () => {
        // Simulate checking network connectivity
        const isConnected = navigator.onLine;
        set({ isConnected });
      },
    }),
    {
      name: 'bip300-explorer-storage',
      partialize: (state) => ({
        isDarkMode: state.isDarkMode,
        currentSidechain: state.currentSidechain,
        refreshInterval: state.refreshInterval,
        showTestnet: state.showTestnet,
        networkSettings: state.networkSettings,
      }),
    }
  )
);
import axios from 'axios';
import { useAppStore } from '../stores/appStore';
import { 
  Block, 
  SidechainInfo, 
  SidechainStats, 
  Transaction, 
  NetworkNode,
  SidechainType,
  ChartData
} from '../types/sidechain';

// Create axios instance
const createApiClient = (sidechain: SidechainType) => {
  const store = useAppStore.getState();
  const { apiEndpoint } = store.networkSettings[sidechain];
  
  return axios.create({
    baseURL: apiEndpoint,
    timeout: 10000,
    headers: {
      'Content-Type': 'application/json',
    },
  });
};

// Mock data generators
const generateMockBlocks = (count: number = 10, startHeight: number = 1000): Block[] => {
  const blocks: Block[] = [];
  const now = Date.now();
  
  for (let i = 0; i < count; i++) {
    const height = startHeight - i;
    const timestamp = now - i * 600000; // Each block 10 minutes apart
    
    blocks.push({
      hash: `000000${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
      height,
      previousBlockHash: i === 0 ? '0000000000000000000000000000000000000000000000000000000000000000' : blocks[i - 1].hash,
      timestamp,
      size: Math.floor(Math.random() * 1000000) + 500000,
      transactionCount: Math.floor(Math.random() * 2000) + 500,
      confirmations: i,
      difficulty: 21.5 + (Math.random() * 2 - 1),
      merkleRoot: `${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
      version: 1,
      nonce: Math.floor(Math.random() * 1000000000),
      bits: '1d00ffff',
    });
  }
  
  return blocks;
};

const generateMockTransactions = (count: number = 20): Transaction[] => {
  const transactions: Transaction[] = [];
  const now = Date.now();
  
  for (let i = 0; i < count; i++) {
    const timestamp = now - i * 60000; // Each tx 1 minute apart
    const txid = `${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`;
    
    transactions.push({
      txid,
      hash: txid,
      version: 1,
      size: Math.floor(Math.random() * 1000) + 200,
      fee: Math.random() * 0.001,
      confirmations: Math.floor(Math.random() * 6),
      blockHeight: 1000 - Math.floor(Math.random() * 10),
      blockHash: `000000${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
      timestamp,
      inputs: [
        {
          prevTxid: `${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
          vout: 0,
          scriptSig: '47304402...',
          sequence: 4294967295,
          value: Math.random() * 1.5,
          address: `bc1q${Math.random().toString(16).slice(2, 30)}`,
        }
      ],
      outputs: [
        {
          value: Math.random() * 1.4,
          n: 0,
          scriptPubKey: '0014...',
          address: `bc1q${Math.random().toString(16).slice(2, 30)}`,
          type: 'witness_v0_keyhash',
        },
        {
          value: Math.random() * 0.1,
          n: 1,
          scriptPubKey: '0014...',
          address: `bc1q${Math.random().toString(16).slice(2, 30)}`,
          type: 'witness_v0_keyhash',
        }
      ],
      isCoinbase: false,
    });
  }
  
  return transactions;
};

const generateMockSidechainInfo = (type: SidechainType): SidechainInfo => {
  const info: Record<SidechainType, Partial<SidechainInfo>> = {
    thunder: {
      name: 'Thunder',
      description: 'Highly scalable sidechain for Bitcoin, supporting up to 8 billion users',
      blockTime: 15,
      tps: 24.5,
      hashrate: '121.5 PH/s',
      logo: 'thunder',
      color: '#F68216',
    },
    zside: {
      name: 'zSide',
      description: 'Privacy-focused sidechain with zCash-like features',
      blockTime: 75,
      tps: 4.2,
      hashrate: '42.3 PH/s',
      logo: 'zside',
      color: '#1A1A2E',
    },
    bitnames: {
      name: 'BitNames',
      description: 'Namecoin-like sidechain for decentralized naming',
      blockTime: 120,
      tps: 2.1,
      hashrate: '28.7 PH/s',
      logo: 'bitnames',
      color: '#4338CA',
    },
  };

  return {
    type,
    status: Math.random() > 0.9 ? 'warning' : 'online',
    blockHeight: 1000 + Math.floor(Math.random() * 100),
    transactions: 14500 + Math.floor(Math.random() * 5000),
    difficulty: 21.5 + (Math.random() * 2 - 1),
    networkVersion: '1.2.3',
    ...info[type],
  } as SidechainInfo;
};

const generateMockSidechainStats = (): SidechainStats => {
  return {
    averageBlockTime: 75 + Math.random() * 30,
    transactionsLast24h: 72500 + Math.floor(Math.random() * 15000),
    pendingTransactions: Math.floor(Math.random() * 500),
    activeAddresses: 25000 + Math.floor(Math.random() * 5000),
    totalTransactions: 9500000 + Math.floor(Math.random() * 500000),
    totalBlocks: 950000 + Math.floor(Math.random() * 50000),
    averageFee: 0.00023 + Math.random() * 0.0001,
    averageTransactionsPerBlock: 850 + Math.floor(Math.random() * 200),
  };
};

const generateMockNodes = (count: number = 15): NetworkNode[] => {
  const nodes: NetworkNode[] = [];
  const now = Date.now();
  
  for (let i = 0; i < count; i++) {
    const lastSeen = now - Math.floor(Math.random() * 3600000);
    
    nodes.push({
      id: `node-${i + 1}`,
      name: `BIP300-Node-${i + 1}`,
      address: `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}:8333`,
      version: `1.${Math.floor(Math.random() * 5)}.${Math.floor(Math.random() * 10)}`,
      connectedSince: now - Math.floor(Math.random() * 86400000 * 30),
      lastSeen,
      status: now - lastSeen > 3600000 ? 'offline' : Math.random() > 0.8 ? 'warning' : 'online',
      latency: Math.floor(Math.random() * 500) + 20,
      location: {
        country: ['United States', 'Germany', 'Japan', 'Canada', 'Brazil', 'Australia'][Math.floor(Math.random() * 6)],
        city: ['New York', 'Berlin', 'Tokyo', 'Toronto', 'São Paulo', 'Sydney'][Math.floor(Math.random() * 6)],
        lat: (Math.random() * 180) - 90,
        long: (Math.random() * 360) - 180,
      },
    });
  }
  
  return nodes;
};

const generateMockChartData = (days: number, dataPoints: number = 24): ChartData => {
  const data: ChartData = {
    label: 'Transactions',
    data: [],
  };
  
  const now = Date.now();
  const increment = 24 * 60 * 60 * 1000 / dataPoints;
  
  for (let i = 0; i < days * dataPoints; i++) {
    data.data.push({
      timestamp: now - (days * 24 * 60 * 60 * 1000) + (i * increment),
      value: Math.floor(Math.random() * 1000) + 500,
    });
  }
  
  return data;
};

// API service object
export const bip300Api = {
  // Blocks
  getLatestBlocks: async (sidechain: SidechainType, limit: number = 10): Promise<Block[]> => {
    // In a real implementation, we would call the API
    // const api = createApiClient(sidechain);
    // const response = await api.get(`/blocks/latest?limit=${limit}`);
    // return response.data;
    
    // Mock implementation for hackathon
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(generateMockBlocks(limit));
      }, 300);
    });
  },
  
  getBlockByHash: async (sidechain: SidechainType, hash: string): Promise<Block> => {
    // Mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        const blocks = generateMockBlocks(1);
        resolve({
          ...blocks[0],
          hash,
        });
      }, 300);
    });
  },
  
  getBlockByHeight: async (sidechain: SidechainType, height: number): Promise<Block> => {
    // Mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        const blocks = generateMockBlocks(1);
        resolve({
          ...blocks[0],
          height,
        });
      }, 300);
    });
  },
  
  // Transactions
  getLatestTransactions: async (sidechain: SidechainType, limit: number = 20): Promise<Transaction[]> => {
    // Mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(generateMockTransactions(limit));
      }, 300);
    });
  },
  
  getTransactionById: async (sidechain: SidechainType, txid: string): Promise<Transaction> => {
    // Mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        const transactions = generateMockTransactions(1);
        resolve({
          ...transactions[0],
          txid,
          hash: txid,
        });
      }, 300);
    });
  },
  
  getBlockTransactions: async (sidechain: SidechainType, blockHash: string, limit: number = 20): Promise<Transaction[]> => {
    // Mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        const transactions = generateMockTransactions(limit);
        transactions.forEach(tx => {
          tx.blockHash = blockHash;
        });
        resolve(transactions);
      }, 300);
    });
  },
  
  // Sidechain info
  getSidechainInfo: async (sidechain: SidechainType): Promise<SidechainInfo> => {
    // Mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(generateMockSidechainInfo(sidechain));
      }, 300);
    });
  },
  
  getSidechainStats: async (sidechain: SidechainType): Promise<SidechainStats> => {
    // Mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(generateMockSidechainStats());
      }, 300);
    });
  },
  
  // Nodes
  getNetworkNodes: async (sidechain: SidechainType): Promise<NetworkNode[]> => {
    // Mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(generateMockNodes());
      }, 300);
    });
  },
  
  // Charts
  getTransactionsChart: async (sidechain: SidechainType, days: number = 7): Promise<ChartData> => {
    // Mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(generateMockChartData(days));
      }, 300);
    });
  },
  
  getBlockTimeChart: async (sidechain: SidechainType, days: number = 7): Promise<ChartData> => {
    // Mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        const data = generateMockChartData(days);
        data.label = 'Block Time (seconds)';
        data.data.forEach(point => {
          point.value = 60 + Math.random() * 30;
        });
        resolve(data);
      }, 300);
    });
  },
  
  getDifficultyChart: async (sidechain: SidechainType, days: number = 7): Promise<ChartData> => {
    // Mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        const data = generateMockChartData(days);
        data.label = 'Difficulty';
        data.data.forEach(point => {
          point.value = 21.5 + (Math.random() * 0.5 - 0.25);
        });
        resolve(data);
      }, 300);
    });
  },
  
  getFeeChart: async (sidechain: SidechainType, days: number = 7): Promise<ChartData> => {
    // Mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        const data = generateMockChartData(days);
        data.label = 'Average Fee (BTC)';
        data.data.forEach(point => {
          point.value = 0.00023 + Math.random() * 0.0001;
        });
        resolve(data);
      }, 300);
    });
  },
};
export type SidechainType = 'thunder' | 'zside' | 'bitnames';

export interface Block {
  hash: string;
  height: number;
  previousBlockHash: string;
  timestamp: number;
  size: number;
  transactionCount: number;
  confirmations: number;
  difficulty: number;
  merkleRoot: string;
  version: number;
  nonce: number;
  bits: string;
}

export interface Transaction {
  txid: string;
  hash: string;
  version: number;
  size: number;
  fee: number;
  confirmations: number;
  blockHeight: number;
  blockHash: string;
  timestamp: number;
  inputs: TransactionInput[];
  outputs: TransactionOutput[];
  isCoinbase: boolean;
}

export interface TransactionInput {
  prevTxid: string;
  vout: number;
  scriptSig: string;
  sequence: number;
  value: number;
  address: string;
}

export interface TransactionOutput {
  value: number;
  n: number;
  scriptPubKey: string;
  address: string;
  type: string;
}

export interface SidechainInfo {
  name: string;
  type: SidechainType;
  description: string;
  status: 'online' | 'offline' | 'warning';
  blockHeight: number;
  blockTime: number; // seconds
  transactions: number; // last 24h
  tps: number; // transactions per second
  difficulty: number;
  hashrate: string;
  networkVersion: string;
  logo: string; // URL to the logo
  color: string; // theme color
}

export interface SidechainStats {
  averageBlockTime: number;
  transactionsLast24h: number;
  pendingTransactions: number;
  activeAddresses: number;
  totalTransactions: number;
  totalBlocks: number;
  averageFee: number;
  averageTransactionsPerBlock: number;
}

export interface NetworkNode {
  id: string;
  name: string;
  address: string;
  version: string;
  connectedSince: number;
  lastSeen: number;
  status: 'online' | 'offline' | 'warning';
  latency: number; // ms
  location?: {
    country: string;
    city: string;
    lat: number;
    long: number;
  };
}

export interface ChartDataPoint {
  timestamp: number;
  value: number;
}

export interface ChartData {
  label: string;
  data: ChartDataPoint[];
  color?: string;
}
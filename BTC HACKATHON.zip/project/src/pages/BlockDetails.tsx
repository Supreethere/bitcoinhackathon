import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { 
  ArrowLeft, 
  Clock, 
  Database, 
  Hash, 
  ArrowRightLeft, 
  FileText, 
  Scale,
  ChevronRight,
  ChevronDown,
  Copy,
  ExternalLink
} from 'lucide-react';
import { useAppStore } from '../stores/appStore';
import { bip300Api } from '../services/api';
import { format } from 'date-fns';
import Card from '../components/common/Card';

const BlockDetails: React.FC = () => {
  const { blockId } = useParams<{ blockId: string }>();
  const { currentSidechain } = useAppStore();
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [showRawData, setShowRawData] = useState(false);

  // Fetch block details
  const { data: block, isLoading: blockLoading } = useQuery({
    queryKey: ['block', currentSidechain, blockId],
    queryFn: () => blockId ? bip300Api.getBlockByHash(currentSidechain, blockId) : Promise.reject('No block ID'),
    enabled: !!blockId,
  });

  // Fetch block transactions
  const { data: transactions, isLoading: txLoading } = useQuery({
    queryKey: ['blockTransactions', currentSidechain, blockId],
    queryFn: () => blockId ? bip300Api.getBlockTransactions(currentSidechain, blockId) : Promise.reject('No block ID'),
    enabled: !!blockId,
  });

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const formatBlockSize = (size: number): string => {
    if (size < 1000) return `${size} B`;
    if (size < 1000000) return `${(size / 1000).toFixed(1)} KB`;
    return `${(size / 1000000).toFixed(1)} MB`;
  };

  if (blockLoading) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  if (!block) {
    return (
      <div className="text-center p-12">
        <h2 className="text-xl font-bold mb-2">Block Not Found</h2>
        <p className="text-gray-400 mb-4">The block you're looking for doesn't exist or hasn't been indexed yet.</p>
        <Link to="/explorer" className="btn btn-primary">
          Back to Explorer
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center">
        <Link to="/explorer" className="text-gray-400 hover:text-white mr-2">
          <ArrowLeft size={20} />
        </Link>
        <div>
          <h1 className="text-2xl font-bold mb-1">Block Details</h1>
          <div className="flex items-center text-gray-400">
            <span>Height</span>
            <ChevronRight size={16} />
            <span className="font-medium text-white">{block.height}</span>
          </div>
        </div>
      </div>

      <Card className="overflow-hidden">
        <div className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-gray-400 text-sm">Block Hash</span>
                  <button 
                    className="text-gray-500 hover:text-gray-300"
                    onClick={() => copyToClipboard(block.hash, 'hash')}
                  >
                    {copiedField === 'hash' ? (
                      <span className="text-xs text-success-500">Copied!</span>
                    ) : (
                      <Copy size={14} />
                    )}
                  </button>
                </div>
                <div className="bg-dark-800 p-2 rounded-md overflow-x-auto">
                  <code className="text-sm text-white font-mono break-all">{block.hash}</code>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-gray-400 text-sm">Previous Block</span>
                </div>
                <div className="bg-dark-800 p-2 rounded-md overflow-x-auto">
                  <Link 
                    to={`/explorer/block/${block.previousBlockHash}`}
                    className="text-sm text-primary-400 hover:text-primary-300 font-mono break-all"
                  >
                    {block.previousBlockHash}
                  </Link>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-gray-400 text-sm">Merkle Root</span>
                </div>
                <div className="bg-dark-800 p-2 rounded-md overflow-x-auto">
                  <code className="text-sm text-white font-mono break-all">{block.merkleRoot}</code>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-dark-800 p-3 rounded-md">
                  <div className="flex items-center space-x-2 mb-1">
                    <Database size={16} className="text-primary-500" />
                    <span className="text-gray-400 text-sm">Height</span>
                  </div>
                  <span className="text-white font-medium">{block.height}</span>
                </div>

                <div className="bg-dark-800 p-3 rounded-md">
                  <div className="flex items-center space-x-2 mb-1">
                    <Clock size={16} className="text-primary-500" />
                    <span className="text-gray-400 text-sm">Timestamp</span>
                  </div>
                  <span className="text-white font-medium">
                    {format(new Date(block.timestamp), 'PPpp')}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-dark-800 p-3 rounded-md">
                  <div className="flex items-center space-x-2 mb-1">
                    <ArrowRightLeft size={16} className="text-primary-500" />
                    <span className="text-gray-400 text-sm">Transactions</span>
                  </div>
                  <span className="text-white font-medium">{block.transactionCount}</span>
                </div>

                <div className="bg-dark-800 p-3 rounded-md">
                  <div className="flex items-center space-x-2 mb-1">
                    <FileText size={16} className="text-primary-500" />
                    <span className="text-gray-400 text-sm">Size</span>
                  </div>
                  <span className="text-white font-medium">{formatBlockSize(block.size)}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-dark-800 p-3 rounded-md">
                  <div className="flex items-center space-x-2 mb-1">
                    <Scale size={16} className="text-primary-500" />
                    <span className="text-gray-400 text-sm">Difficulty</span>
                  </div>
                  <span className="text-white font-medium">{block.difficulty.toFixed(2)}</span>
                </div>

                <div className="bg-dark-800 p-3 rounded-md">
                  <div className="flex items-center space-x-2 mb-1">
                    <Hash size={16} className="text-primary-500" />
                    <span className="text-gray-400 text-sm">Nonce</span>
                  </div>
                  <span className="text-white font-medium">{block.nonce}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Card>

      <Card 
        title={`Transactions (${block.transactionCount})`}
        className="overflow-hidden"
      >
        {txLoading ? (
          <div className="p-6 flex justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
          </div>
        ) : transactions && transactions.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-gray-400 text-sm border-b border-dark-600">
                  <th className="px-4 py-3">TX Hash</th>
                  <th className="px-4 py-3">Fee</th>
                  <th className="px-4 py-3">Size</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-dark-600">
                {transactions.map((tx) => (
                  <tr
                    key={tx.txid}
                    className="hover:bg-dark-700/50 transition-colors"
                  >
                    <td className="px-4 py-3">
                      <Link
                        to={`/transactions/${tx.txid}`}
                        className="text-primary-400 hover:text-primary-300 font-mono"
                      >
                        {tx.txid.substring(0, 10)}...{tx.txid.substring(tx.txid.length - 10)}
                      </Link>
                      {tx.isCoinbase && (
                        <span className="ml-2 badge badge-primary">Coinbase</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-gray-400">{tx.fee.toFixed(8)} BTC</td>
                    <td className="px-4 py-3 text-gray-400">{tx.size} bytes</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-6 text-center text-gray-400">
            No transactions found for this block.
          </div>
        )}
      </Card>

      <Card>
        <div className="p-4">
          <button 
            className="flex items-center justify-between w-full text-left"
            onClick={() => setShowRawData(!showRawData)}
          >
            <span className="font-medium">Raw Block Data</span>
            {showRawData ? <ChevronDown size={18} /> : <ChevronRight size={18} />}
          </button>

          {showRawData && (
            <div className="mt-4 bg-dark-800 p-3 rounded-md overflow-x-auto">
              <pre className="text-sm text-white font-mono">
                {JSON.stringify(block, null, 2)}
              </pre>
            </div>
          )}
        </div>
      </Card>

      <div className="flex justify-center py-4">
        <a 
          href={`https://mempool.space/block/${block.hash}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center text-gray-400 hover:text-primary-400 transition-colors"
        >
          View on external explorer <ExternalLink size={14} className="ml-1" />
        </a>
      </div>
    </div>
  );
};

export default BlockDetails;
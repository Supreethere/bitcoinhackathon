import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ArrowDown, ArrowUp, Clock, Coins, Database, Zap } from 'lucide-react';
import { useAppStore } from '../stores/appStore';
import { bip300Api } from '../services/api';
import InfoCard from '../components/common/InfoCard';
import Card from '../components/common/Card';
import BlockList from '../components/blocks/BlockList';
import TransactionList from '../components/transactions/TransactionList';
import LineChart from '../components/common/LineChart';

const Dashboard: React.FC = () => {
  const { currentSidechain, refreshInterval } = useAppStore();

  // Fetch sidechain info
  const { data: sidechainInfo, isLoading: infoLoading } = useQuery({
    queryKey: ['sidechainInfo', currentSidechain],
    queryFn: () => bip300Api.getSidechainInfo(currentSidechain),
    refetchInterval: refreshInterval,
  });

  // Fetch sidechain stats
  const { data: sidechainStats, isLoading: statsLoading } = useQuery({
    queryKey: ['sidechainStats', currentSidechain],
    queryFn: () => bip300Api.getSidechainStats(currentSidechain),
    refetchInterval: refreshInterval,
  });

  // Fetch latest blocks
  const { data: latestBlocks, isLoading: blocksLoading } = useQuery({
    queryKey: ['latestBlocks', currentSidechain],
    queryFn: () => bip300Api.getLatestBlocks(currentSidechain, 10),
    refetchInterval: refreshInterval,
  });

  // Fetch latest transactions
  const { data: latestTransactions, isLoading: transactionsLoading } = useQuery({
    queryKey: ['latestTransactions', currentSidechain],
    queryFn: () => bip300Api.getLatestTransactions(currentSidechain, 10),
    refetchInterval: refreshInterval,
  });

  // Fetch transaction chart data
  const { data: transactionsChart, isLoading: chartLoading } = useQuery({
    queryKey: ['transactionsChart', currentSidechain],
    queryFn: () => bip300Api.getTransactionsChart(currentSidechain, 7),
    refetchInterval: refreshInterval * 2,
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">BIP300 Sidechain Explorer</h1>
        <p className="text-gray-400">
          Real-time monitoring and analytics for {sidechainInfo?.name || currentSidechain}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <InfoCard
          title="Block Height"
          value={infoLoading ? "Loading..." : sidechainInfo?.blockHeight || 0}
          icon={<Database size={18} />}
          loading={infoLoading}
        />
        <InfoCard
          title="Transactions (24h)"
          value={infoLoading ? "Loading..." : sidechainInfo?.transactions.toLocaleString() || 0}
          icon={<ArrowDown size={18} />}
          change={4.2}
          loading={infoLoading}
        />
        <InfoCard
          title="TPS"
          value={infoLoading ? "Loading..." : sidechainInfo?.tps || 0}
          icon={<Zap size={18} />}
          change={1.5}
          loading={infoLoading}
        />
        <InfoCard
          title="Avg Block Time"
          value={statsLoading ? "Loading..." : `${(sidechainStats?.averageBlockTime || 0).toFixed(0)}s`}
          icon={<Clock size={18} />}
          change={-2.1}
          loading={statsLoading}
        />
      </div>

      <Card title="Transaction Activity (7 Days)" className="w-full">
        {chartLoading ? (
          <div className="h-72 flex items-center justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
          </div>
        ) : (
          transactionsChart && <LineChart data={transactionsChart} height={300} />
        )}
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <BlockList
          blocks={latestBlocks || []}
          loading={blocksLoading}
          limit={5}
        />
        <TransactionList
          transactions={latestTransactions || []}
          loading={transactionsLoading}
          limit={5}
        />
      </div>

      <div className="bg-dark-700 border border-dark-600 rounded-lg p-6 mt-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <h2 className="text-xl font-bold mb-2">Understanding BIP300 Sidechains</h2>
            <p className="text-gray-400 mb-4">
              BIP300 provides a way to create customizable sidechains on Bitcoin without sacrificing security.
            </p>
          </div>
          <a
            href="/learn"
            className="btn btn-primary mt-2 md:mt-0"
          >
            Learn More
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
          <div className="bg-dark-800 p-4 rounded-lg border border-dark-600">
            <Zap size={24} className="text-primary-500 mb-2" />
            <h3 className="font-bold mb-1">Thunder</h3>
            <p className="text-sm text-gray-400">
              High-throughput sidechain designed to scale to billions of users
            </p>
          </div>
          <div className="bg-dark-800 p-4 rounded-lg border border-dark-600">
            <ArrowUp size={24} className="text-secondary-500 mb-2" />
            <h3 className="font-bold mb-1">zSide</h3>
            <p className="text-sm text-gray-400">
              Privacy-focused sidechain with zCash-like features
            </p>
          </div>
          <div className="bg-dark-800 p-4 rounded-lg border border-dark-600">
            <Coins size={24} className="text-accent-500 mb-2" />
            <h3 className="font-bold mb-1">BitNames</h3>
            <p className="text-sm text-gray-400">
              Decentralized naming system inspired by Namecoin
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
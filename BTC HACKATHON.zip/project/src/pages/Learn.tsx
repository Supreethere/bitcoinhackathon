import React from 'react';
import { ExternalLink, Shield, Zap, Lock } from 'lucide-react';
import Card from '../components/common/Card';

const Learn: React.FC = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">Learn BIP300</h1>
        <p className="text-gray-400">
          Understand how BIP300 provides secure and decentralized sidechains for Bitcoin
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="flex flex-col h-full" delay={0}>
          <div className="p-4 flex-1">
            <div className="mb-4 rounded-full w-12 h-12 flex items-center justify-center bg-primary-500/10">
              <Shield className="text-primary-500" size={24} />
            </div>
            <h3 className="text-xl font-bold mb-2">What is BIP300?</h3>
            <p className="text-gray-400">
              BIP300 is a Bitcoin Improvement Proposal that enables the creation of sidechains 
              that are secured by Bitcoin's Proof of Work without requiring a separate token or 
              centralized federation.
            </p>
          </div>
          <div className="p-4 border-t border-dark-600">
            <a 
              href="https://github.com/drivechain-project/docs/blob/master/bip-0300.mediawiki" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-primary-400 hover:text-primary-300 flex items-center"
            >
              Read the BIP300 Specification
              <ExternalLink size={14} className="ml-1" />
            </a>
          </div>
        </Card>

        <Card className="flex flex-col h-full" delay={1}>
          <div className="p-4 flex-1">
            <div className="mb-4 rounded-full w-12 h-12 flex items-center justify-center bg-primary-500/10">
              <Zap className="text-primary-500" size={24} />
            </div>
            <h3 className="text-xl font-bold mb-2">How BIP300 Works</h3>
            <p className="text-gray-400">
              BIP300 uses a two-way peg mechanism that allows bitcoins to move between Bitcoin's 
              main chain and sidechains. Miners validate sidechain blocks through merged-mining 
              and approve transfers of bitcoin to and from sidechains.
            </p>
          </div>
          <div className="p-4 border-t border-dark-600">
            <a 
              href="https://layertwolabs.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-primary-400 hover:text-primary-300 flex items-center"
            >
              Learn more at LayerTwo Labs
              <ExternalLink size={14} className="ml-1" />
            </a>
          </div>
        </Card>

        <Card className="flex flex-col h-full" delay={2}>
          <div className="p-4 flex-1">
            <div className="mb-4 rounded-full w-12 h-12 flex items-center justify-center bg-primary-500/10">
              <Lock className="text-primary-500" size={24} />
            </div>
            <h3 className="text-xl font-bold mb-2">Security Model</h3>
            <p className="text-gray-400">
              BIP300 sidechains inherit Bitcoin's security. The security model relies on Bitcoin's 
              miners to validate sidechain blocks and prevent invalid withdrawals through a blind 
              merged mining process.
            </p>
          </div>
          <div className="p-4 border-t border-dark-600">
            <a 
              href="https://github.com/drivechain-project/docs" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-primary-400 hover:text-primary-300 flex items-center"
            >
              View technical documentation
              <ExternalLink size={14} className="ml-1" />
            </a>
          </div>
        </Card>
      </div>

      <Card title="Available BIP300 Sidechains">
        <div className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-dark-800 p-4 rounded-lg border border-dark-600 h-full">
              <div className="flex items-center mb-3">
                <div className="w-10 h-10 bg-primary-500/10 rounded-full flex items-center justify-center mr-3">
                  <Zap size={20} className="text-primary-500" />
                </div>
                <h3 className="text-lg font-bold">Thunder</h3>
              </div>
              <p className="text-sm text-gray-400 mb-4">
                A high-throughput sidechain designed to scale to billions of users. Thunder can 
                process thousands of transactions per second with very low fees.
              </p>
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">Block Time:</span>
                  <span className="text-white">15 seconds</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">TPS Capacity:</span>
                  <span className="text-white">~20,000</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">Use Case:</span>
                  <span className="text-white">Payment Networks</span>
                </div>
              </div>
            </div>

            <div className="bg-dark-800 p-4 rounded-lg border border-dark-600 h-full">
              <div className="flex items-center mb-3">
                <div className="w-10 h-10 bg-secondary-500/10 rounded-full flex items-center justify-center mr-3">
                  <Lock size={20} className="text-secondary-500" />
                </div>
                <h3 className="text-lg font-bold">zSide</h3>
              </div>
              <p className="text-sm text-gray-400 mb-4">
                A privacy-focused sidechain with zCash-like features. zSide enables confidential 
                transactions while maintaining the security of Bitcoin.
              </p>
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">Block Time:</span>
                  <span className="text-white">75 seconds</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">TPS Capacity:</span>
                  <span className="text-white">~40</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">Use Case:</span>
                  <span className="text-white">Privacy</span>
                </div>
              </div>
            </div>

            <div className="bg-dark-800 p-4 rounded-lg border border-dark-600 h-full">
              <div className="flex items-center mb-3">
                <div className="w-10 h-10 bg-accent-500/10 rounded-full flex items-center justify-center mr-3">
                  <Shield size={20} className="text-accent-500" />
                </div>
                <h3 className="text-lg font-bold">BitNames</h3>
              </div>
              <p className="text-sm text-gray-400 mb-4">
                A decentralized naming system inspired by Namecoin. BitNames allows users to 
                register and manage domain names on a Bitcoin sidechain.
              </p>
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">Block Time:</span>
                  <span className="text-white">120 seconds</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">TPS Capacity:</span>
                  <span className="text-white">~100</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">Use Case:</span>
                  <span className="text-white">Naming System</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Card>

      <Card title="How to Use BIP300 Sidechains">
        <div className="p-4">
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold mb-3">Getting Started</h3>
              <ol className="list-decimal list-inside space-y-3 text-gray-400">
                <li>
                  <span className="text-white font-medium">Download the Software</span>
                  <p className="mt-1 ml-6">
                    Visit the LayerTwo Labs website to download the latest version of the BIP300 
                    sidechain software. Currently available for Linux, macOS, and Windows.
                  </p>
                </li>
                <li>
                  <span className="text-white font-medium">Run a Node</span>
                  <p className="mt-1 ml-6">
                    Launch the software and select which sidechain(s) you want to run. You'll need 
                    to have a Bitcoin full node running as well.
                  </p>
                </li>
                <li>
                  <span className="text-white font-medium">Deposit Bitcoin</span>
                  <p className="mt-1 ml-6">
                    Use the deposit function to move Bitcoin from the main chain to the sidechain 
                    of your choice. This process can take up to a day for security reasons.
                  </p>
                </li>
                <li>
                  <span className="text-white font-medium">Start Using the Sidechain</span>
                  <p className="mt-1 ml-6">
                    Once your deposit is confirmed, you can start using the sidechain features, 
                    whether it's fast payments, private transactions, or name registrations.
                  </p>
                </li>
              </ol>
            </div>

            <div className="flex justify-center">
              <a
                href="https://layertwolabs.com/download"
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-primary"
              >
                Download BIP300 Software
              </a>
            </div>
          </div>
        </div>
      </Card>

      <Card title="BIP300 Technical Resources" className="mb-8">
        <div className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <a
              href="https://github.com/LayerTwoLabs"
              target="_blank"
              rel="noopener noreferrer"
              className="block bg-dark-800 p-4 rounded-lg border border-dark-600 hover:border-primary-500/50 transition-colors"
            >
              <h3 className="text-lg font-bold mb-2 text-white">Source Code</h3>
              <p className="text-sm text-gray-400">
                Explore the open-source code behind BIP300 sidechains and contribute to their development.
              </p>
            </a>
            <a
              href="https://github.com/drivechain-project/docs"
              target="_blank"
              rel="noopener noreferrer"
              className="block bg-dark-800 p-4 rounded-lg border border-dark-600 hover:border-primary-500/50 transition-colors"
            >
              <h3 className="text-lg font-bold mb-2 text-white">Technical Documentation</h3>
              <p className="text-sm text-gray-400">
                Read detailed technical documentation about how BIP300 works and how to build on top of it.
              </p>
            </a>
            <a
              href="https://bitcoin.stackexchange.com/questions/tagged/sidechains"
              target="_blank"
              rel="noopener noreferrer"
              className="block bg-dark-800 p-4 rounded-lg border border-dark-600 hover:border-primary-500/50 transition-colors"
            >
              <h3 className="text-lg font-bold mb-2 text-white">Community Support</h3>
              <p className="text-sm text-gray-400">
                Get help from the community on Stack Exchange and other forums dedicated to Bitcoin sidechains.
              </p>
            </a>
            <a
              href="https://bitcoinops.org/en/topics/sidechains/"
              target="_blank"
              rel="noopener noreferrer"
              className="block bg-dark-800 p-4 rounded-lg border border-dark-600 hover:border-primary-500/50 transition-colors"
            >
              <h3 className="text-lg font-bold mb-2 text-white">Educational Resources</h3>
              <p className="text-sm text-gray-400">
                Learn about sidechains and how they can enhance Bitcoin's capabilities from Bitcoin Optech.
              </p>
            </a>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default Learn;
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ArrowDownUp, Calendar, Filter, Search } from 'lucide-react';
import { useAppStore } from '../stores/appStore';
import { bip300Api } from '../services/api';
import { Link } from 'react-router-dom';
import { formatDistance } from 'date-fns';
import Card from '../components/common/Card';

const Transactions: React.FC = () => {
  const { currentSidechain, refreshInterval } = useAppStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');
  const [filterConfirmed, setFilterConfirmed] = useState<'all' | 'confirmed' | 'unconfirmed'>('all');

  // Fetch latest transactions
  const { data: transactions, isLoading, error } = useQuery({
    queryKey: ['transactions', currentSidechain],
    queryFn: () => bip300Api.getLatestTransactions(currentSidechain, 100),
    refetchInterval: refreshInterval,
  });

  // Filter and sort transactions
  const filteredTransactions = transactions?.filter((tx) => {
    // Apply search filter
    const matchesSearch = !searchTerm || 
      tx.txid.toLowerCase().includes(searchTerm.toLowerCase()) || 
      tx.inputs.some(input => input.address.toLowerCase().includes(searchTerm.toLowerCase())) ||
      tx.outputs.some(output => output.address.toLowerCase().includes(searchTerm.toLowerCase()));
    
    // Apply confirmation filter
    const matchesConfirmation = 
      filterConfirmed === 'all' || 
      (filterConfirmed === 'confirmed' && tx.confirmations > 0) || 
      (filterConfirmed === 'unconfirmed' && tx.confirmations === 0);
    
    return matchesSearch && matchesConfirmation;
  });

  // Sort transactions
  const sortedTransactions = filteredTransactions
    ? [...filteredTransactions].sort((a, b) => {
        if (sortOrder === 'desc') {
          return b.timestamp - a.timestamp;
        } else {
          return a.timestamp - b.timestamp;
        }
      })
    : [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">Transactions</h1>
        <p className="text-gray-400">
          Browse and search through the latest transactions on the {currentSidechain} sidechain
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
          <input
            type="text"
            placeholder="Search by transaction ID or address..."
            className="pl-10 pr-4 py-2 w-full bg-dark-700 border border-dark-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500/50"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <select
            className="bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500/50"
            value={filterConfirmed}
            onChange={(e) => setFilterConfirmed(e.target.value as 'all' | 'confirmed' | 'unconfirmed')}
          >
            <option value="all">All Transactions</option>
            <option value="confirmed">Confirmed Only</option>
            <option value="unconfirmed">Unconfirmed Only</option>
          </select>

          <button
            className="btn btn-outline flex items-center gap-2"
            onClick={() => setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc')}
          >
            <Calendar size={16} />
            <span>{sortOrder === 'desc' ? 'Newest First' : 'Oldest First'}</span>
          </button>
        </div>
      </div>

      <Card>
        {isLoading ? (
          <div className="p-6 flex justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
          </div>
        ) : error ? (
          <div className="p-6 text-center text-error-500">
            Failed to load transactions. Please try again.
          </div>
        ) : sortedTransactions.length === 0 ? (
          <div className="p-6 text-center text-gray-400">
            No transactions found matching your search criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-gray-400 text-sm">
                  <th className="px-4 py-3">TX Hash</th>
                  <th className="px-4 py-3">Age</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Size</th>
                  <th className="px-4 py-3">Fee</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-dark-600">
                {sortedTransactions.map((tx) => (
                  <tr
                    key={tx.txid}
                    className="hover:bg-dark-700/50 transition-colors"
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center">
                        <Link
                          to={`/transactions/${tx.txid}`}
                          className="text-primary-400 hover:text-primary-300 font-mono"
                        >
                          {tx.txid.substring(0, 10)}...{tx.txid.substring(tx.txid.length - 10)}
                        </Link>
                        {tx.isCoinbase && (
                          <span className="ml-2 badge badge-primary">Coinbase</span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-gray-400">
                      {formatDistance(new Date(tx.timestamp), new Date(), { addSuffix: true })}
                    </td>
                    <td className="px-4 py-3">
                      {tx.confirmations === 0 ? (
                        <span className="badge badge-warning">Unconfirmed</span>
                      ) : tx.confirmations < 6 ? (
                        <span className="badge badge-primary">{tx.confirmations} Confirmations</span>
                      ) : (
                        <span className="badge badge-success">Confirmed</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-gray-400">{tx.size} bytes</td>
                    <td className="px-4 py-3 text-gray-400">{tx.fee.toFixed(8)} BTC</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
};

export default Transactions;
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAppStore } from '../stores/appStore';
import { bip300Api } from '../services/api';
import Card from '../components/common/Card';
import InfoCard from '../components/common/InfoCard';
import { ArrowRightLeft, Clock, Activity, DollarSign } from 'lucide-react';
import LineChart from '../components/common/LineChart';

const Analytics: React.FC = () => {
  const { currentSidechain, refreshInterval } = useAppStore();
  const [timeRange, setTimeRange] = useState<'1d' | '7d' | '30d' | '90d'>('7d');
  
  // Get day count from time range
  const getDayCount = () => {
    switch (timeRange) {
      case '1d': return 1;
      case '7d': return 7;
      case '30d': return 30;
      case '90d': return 90;
      default: return 7;
    }
  };

  // Fetch sidechain stats
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['sidechainStats', currentSidechain],
    queryFn: () => bip300Api.getSidechainStats(currentSidechain),
    refetchInterval: refreshInterval,
  });

  // Fetch transaction chart data
  const { data: transactionsChart, isLoading: txChartLoading } = useQuery({
    queryKey: ['transactionsChart', currentSidechain, timeRange],
    queryFn: () => bip300Api.getTransactionsChart(currentSidechain, getDayCount()),
    refetchInterval: refreshInterval * 2,
  });

  // Fetch block time chart data
  const { data: blockTimeChart, isLoading: blockChartLoading } = useQuery({
    queryKey: ['blockTimeChart', currentSidechain, timeRange],
    queryFn: () => bip300Api.getBlockTimeChart(currentSidechain, getDayCount()),
    refetchInterval: refreshInterval * 2,
  });

  // Fetch difficulty chart data
  const { data: difficultyChart, isLoading: diffChartLoading } = useQuery({
    queryKey: ['difficultyChart', currentSidechain, timeRange],
    queryFn: () => bip300Api.getDifficultyChart(currentSidechain, getDayCount()),
    refetchInterval: refreshInterval * 2,
  });

  // Fetch fee chart data
  const { data: feeChart, isLoading: feeChartLoading } = useQuery({
    queryKey: ['feeChart', currentSidechain, timeRange],
    queryFn: () => bip300Api.getFeeChart(currentSidechain, getDayCount()),
    refetchInterval: refreshInterval * 2,
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">Sidechain Analytics</h1>
        <p className="text-gray-400">
          Performance metrics and statistics for the {currentSidechain} sidechain
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <InfoCard
          title="Total Transactions"
          value={statsLoading ? "Loading..." : stats?.totalTransactions.toLocaleString() || 0}
          icon={<ArrowRightLeft size={18} />}
          loading={statsLoading}
        />
        <InfoCard
          title="Active Addresses"
          value={statsLoading ? "Loading..." : stats?.activeAddresses.toLocaleString() || 0}
          icon={<Activity size={18} />}
          change={5.8}
          loading={statsLoading}
        />
        <InfoCard
          title="Average Block Time"
          value={statsLoading ? "Loading..." : `${(stats?.averageBlockTime || 0).toFixed(1)}s` || 0}
          icon={<Clock size={18} />}
          change={-1.2}
          loading={statsLoading}
        />
        <InfoCard
          title="Average Fee"
          value={statsLoading ? "Loading..." : `${(stats?.averageFee || 0).toFixed(8)}` || 0}
          icon={<DollarSign size={18} />}
          subtitle="BTC"
          change={2.5}
          loading={statsLoading}
        />
      </div>

      <div className="flex justify-end pb-2">
        <div className="inline-flex rounded-md shadow-sm">
          {(['1d', '7d', '30d', '90d'] as const).map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-4 py-1.5 text-sm font-medium ${
                timeRange === range
                  ? 'bg-dark-600 text-white'
                  : 'bg-dark-800 text-gray-400 hover:text-white hover:bg-dark-700'
              } ${
                range === '1d' ? 'rounded-l-md' : ''
              } ${
                range === '90d' ? 'rounded-r-md' : ''
              } border border-dark-600`}
            >
              {range}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card title="Transaction Volume" className="w-full">
          {txChartLoading ? (
            <div className="h-72 flex items-center justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
            </div>
          ) : (
            transactionsChart && <LineChart data={transactionsChart} height={300} />
          )}
        </Card>

        <Card title="Average Block Time (seconds)" className="w-full">
          {blockChartLoading ? (
            <div className="h-72 flex items-center justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
            </div>
          ) : (
            blockTimeChart && <LineChart data={blockTimeChart} height={300} />
          )}
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card title="Network Difficulty" className="w-full">
          {diffChartLoading ? (
            <div className="h-72 flex items-center justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
            </div>
          ) : (
            difficultyChart && <LineChart data={difficultyChart} height={300} />
          )}
        </Card>

        <Card title="Average Fee (BTC)" className="w-full">
          {feeChartLoading ? (
            <div className="h-72 flex items-center justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
            </div>
          ) : (
            feeChart && (
              <LineChart
                data={feeChart}
                height={300}
                tooltipFormatter={(value) => value.toFixed(8)}
              />
            )
          )}
        </Card>
      </div>

      <Card title="Sidechain Performance Metrics" className="w-full">
        {statsLoading ? (
          <div className="h-72 flex items-center justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
          </div>
        ) : (
          <div className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="bg-dark-800 p-4 rounded-md">
                <h3 className="text-gray-400 text-sm mb-2">Transactions (24h)</h3>
                <p className="text-xl font-medium text-white">{stats?.transactionsLast24h.toLocaleString()}</p>
              </div>
              <div className="bg-dark-800 p-4 rounded-md">
                <h3 className="text-gray-400 text-sm mb-2">Pending Transactions</h3>
                <p className="text-xl font-medium text-white">{stats?.pendingTransactions.toLocaleString()}</p>
              </div>
              <div className="bg-dark-800 p-4 rounded-md">
                <h3 className="text-gray-400 text-sm mb-2">Total Blocks</h3>
                <p className="text-xl font-medium text-white">{stats?.totalBlocks.toLocaleString()}</p>
              </div>
              <div className="bg-dark-800 p-4 rounded-md">
                <h3 className="text-gray-400 text-sm mb-2">Avg. Transactions Per Block</h3>
                <p className="text-xl font-medium text-white">{stats?.averageTransactionsPerBlock.toLocaleString()}</p>
              </div>
              <div className="bg-dark-800 p-4 rounded-md">
                <h3 className="text-gray-400 text-sm mb-2">Avg. Block Time</h3>
                <p className="text-xl font-medium text-white">{(stats?.averageBlockTime || 0).toFixed(2)} seconds</p>
              </div>
              <div className="bg-dark-800 p-4 rounded-md">
                <h3 className="text-gray-400 text-sm mb-2">Avg. Fee</h3>
                <p className="text-xl font-medium text-white">{(stats?.averageFee || 0).toFixed(8)} BTC</p>
              </div>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
};

export default Analytics;
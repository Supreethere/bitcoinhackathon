import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { 
  ArrowLeft, 
  Clock, 
  Check, 
  ArrowDownToLine, 
  ArrowUpFromLine, 
  Copy,
  ChevronRight,
  ChevronDown,
  ExternalLink
} from 'lucide-react';
import { useAppStore } from '../stores/appStore';
import { bip300Api } from '../services/api';
import { format } from 'date-fns';
import Card from '../components/common/Card';

const TransactionDetails: React.FC = () => {
  const { txId } = useParams<{ txId: string }>();
  const { currentSidechain } = useAppStore();
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [showRawData, setShowRawData] = useState(false);

  // Fetch transaction details
  const { data: transaction, isLoading } = useQuery({
    queryKey: ['transaction', currentSidechain, txId],
    queryFn: () => txId ? bip300Api.getTransactionById(currentSidechain, txId) : Promise.reject('No transaction ID'),
    enabled: !!txId,
  });

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  if (!transaction) {
    return (
      <div className="text-center p-12">
        <h2 className="text-xl font-bold mb-2">Transaction Not Found</h2>
        <p className="text-gray-400 mb-4">The transaction you're looking for doesn't exist or hasn't been indexed yet.</p>
        <Link to="/transactions" className="btn btn-primary">
          Back to Transactions
        </Link>
      </div>
    );
  }

  const totalInput = transaction.inputs.reduce((sum, input) => sum + input.value, 0);
  const totalOutput = transaction.outputs.reduce((sum, output) => sum + output.value, 0);
  const fee = transaction.isCoinbase ? 0 : totalInput - totalOutput;

  return (
    <div className="space-y-6">
      <div className="flex items-center">
        <Link to="/transactions" className="text-gray-400 hover:text-white mr-2">
          <ArrowLeft size={20} />
        </Link>
        <div>
          <h1 className="text-2xl font-bold mb-1">Transaction Details</h1>
          <div className="flex items-center text-gray-400">
            <span>TX</span>
            <ChevronRight size={16} />
            <span className="font-mono text-white truncate max-w-[200px] md:max-w-[400px]">
              {transaction.txid.substring(0, 12)}...{transaction.txid.substring(transaction.txid.length - 12)}
            </span>
          </div>
        </div>
      </div>

      <Card className="overflow-hidden">
        <div className="p-4">
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-gray-400 text-sm">Transaction Hash</span>
                <button 
                  className="text-gray-500 hover:text-gray-300"
                  onClick={() => copyToClipboard(transaction.txid, 'txid')}
                >
                  {copiedField === 'txid' ? (
                    <span className="text-xs text-success-500">Copied!</span>
                  ) : (
                    <Copy size={14} />
                  )}
                </button>
              </div>
              <div className="bg-dark-800 p-2 rounded-md overflow-x-auto">
                <code className="text-sm text-white font-mono break-all">{transaction.txid}</code>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-dark-800 p-3 rounded-md">
                <div className="flex items-center space-x-2 mb-1">
                  <Clock size={16} className="text-primary-500" />
                  <span className="text-gray-400 text-sm">Timestamp</span>
                </div>
                <span className="text-white font-medium">
                  {format(new Date(transaction.timestamp), 'PPpp')}
                </span>
              </div>

              <div className="bg-dark-800 p-3 rounded-md">
                <div className="flex items-center space-x-2 mb-1">
                  <Check size={16} className="text-primary-500" />
                  <span className="text-gray-400 text-sm">Status</span>
                </div>
                {transaction.confirmations === 0 ? (
                  <span className="text-warning-500 font-medium">Unconfirmed</span>
                ) : (
                  <span className="text-success-500 font-medium">{transaction.confirmations} Confirmations</span>
                )}
              </div>

              <div className="bg-dark-800 p-3 rounded-md">
                <div className="flex items-center space-x-2 mb-1">
                  <ArrowDownToLine size={16} className="text-primary-500" />
                  <span className="text-gray-400 text-sm">Block</span>
                </div>
                {transaction.blockHeight ? (
                  <Link to={`/explorer/block/${transaction.blockHash}`} className="text-primary-400 hover:text-primary-300">
                    {transaction.blockHeight}
                  </Link>
                ) : (
                  <span className="text-gray-400">Mempool (Unconfirmed)</span>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-dark-800 p-3 rounded-md">
                <div className="flex items-center space-x-2 mb-1">
                  <span className="text-gray-400 text-sm">Size</span>
                </div>
                <span className="text-white font-medium">{transaction.size} bytes</span>
              </div>

              <div className="bg-dark-800 p-3 rounded-md">
                <div className="flex items-center space-x-2 mb-1">
                  <span className="text-gray-400 text-sm">Fee</span>
                </div>
                <span className="text-white font-medium">{fee.toFixed(8)} BTC</span>
              </div>

              <div className="bg-dark-800 p-3 rounded-md">
                <div className="flex items-center space-x-2 mb-1">
                  <span className="text-gray-400 text-sm">Fee Rate</span>
                </div>
                <span className="text-white font-medium">
                  {transaction.size > 0 ? ((fee * 100000000) / transaction.size).toFixed(1) : 0} sat/byte
                </span>
              </div>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card title={`Inputs (${transaction.inputs.length})`} className="h-full">
          <div className="p-4">
            {transaction.inputs.map((input, index) => (
              <div key={index} className="mb-4 last:mb-0 bg-dark-800 p-3 rounded-md">
                <div className="flex justify-between mb-2">
                  <div className="flex items-center">
                    <ArrowUpFromLine size={14} className="text-primary-500 mr-1" />
                    <span className="text-sm text-gray-400">Input #{index}</span>
                  </div>
                  <span className="text-white font-medium">{input.value.toFixed(8)} BTC</span>
                </div>
                <div className="text-xs text-gray-400 mb-1">Address</div>
                <div className="font-mono text-sm text-primary-400 break-all">
                  {input.address}
                </div>
                {input.prevTxid && (
                  <>
                    <div className="text-xs text-gray-400 mt-2 mb-1">Previous TX</div>
                    <Link 
                      to={`/transactions/${input.prevTxid}`}
                      className="font-mono text-xs text-primary-400 hover:text-primary-300 break-all"
                    >
                      {input.prevTxid}
                    </Link>
                  </>
                )}
              </div>
            ))}
          </div>
        </Card>

        <Card title={`Outputs (${transaction.outputs.length})`} className="h-full">
          <div className="p-4">
            {transaction.outputs.map((output, index) => (
              <div key={index} className="mb-4 last:mb-0 bg-dark-800 p-3 rounded-md">
                <div className="flex justify-between mb-2">
                  <div className="flex items-center">
                    <ArrowDownToLine size={14} className="text-success-500 mr-1" />
                    <span className="text-sm text-gray-400">Output #{index}</span>
                  </div>
                  <span className="text-white font-medium">{output.value.toFixed(8)} BTC</span>
                </div>
                <div className="text-xs text-gray-400 mb-1">Address</div>
                <div className="font-mono text-sm text-primary-400 break-all">
                  {output.address}
                </div>
                <div className="text-xs text-gray-400 mt-2 mb-1">Type</div>
                <div className="font-mono text-xs text-gray-400">{output.type}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card>
        <div className="p-4">
          <button 
            className="flex items-center justify-between w-full text-left"
            onClick={() => setShowRawData(!showRawData)}
          >
            <span className="font-medium">Raw Transaction Data</span>
            {showRawData ? <ChevronDown size={18} /> : <ChevronRight size={18} />}
          </button>

          {showRawData && (
            <div className="mt-4 bg-dark-800 p-3 rounded-md overflow-x-auto">
              <pre className="text-sm text-white font-mono">
                {JSON.stringify(transaction, null, 2)}
              </pre>
            </div>
          )}
        </div>
      </Card>

      <div className="flex justify-center py-4">
        <a 
          href={`https://mempool.space/tx/${transaction.txid}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center text-gray-400 hover:text-primary-400 transition-colors"
        >
          View on external explorer <ExternalLink size={14} className="ml-1" />
        </a>
      </div>
    </div>
  );
};

export default TransactionDetails;
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ArrowDownUp, Filter, Search } from 'lucide-react';
import { useAppStore } from '../stores/appStore';
import { bip300Api } from '../services/api';
import { Block } from '../types/sidechain';
import { Link } from 'react-router-dom';
import { formatDistance } from 'date-fns';
import Card from '../components/common/Card';

const BlockExplorer: React.FC = () => {
  const { currentSidechain, refreshInterval } = useAppStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  // Fetch latest blocks
  const { data: blocks, isLoading, error } = useQuery({
    queryKey: ['blocks', currentSidechain],
    queryFn: () => bip300Api.getLatestBlocks(currentSidechain, 50),
    refetchInterval: refreshInterval,
  });

  const formatBlockSize = (size: number): string => {
    if (size < 1000) return `${size} B`;
    if (size < 1000000) return `${(size / 1000).toFixed(1)} KB`;
    return `${(size / 1000000).toFixed(1)} MB`;
  };

  // Filter blocks based on search term
  const filteredBlocks = blocks?.filter((block) => {
    if (!searchTerm) return true;
    return (
      block.height.toString().includes(searchTerm) ||
      block.hash.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  // Sort blocks
  const sortedBlocks = filteredBlocks
    ? [...filteredBlocks].sort((a, b) => {
        if (sortOrder === 'desc') {
          return b.height - a.height;
        } else {
          return a.height - b.height;
        }
      })
    : [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">Block Explorer</h1>
        <p className="text-gray-400">
          Browse and search through the latest blocks on the {currentSidechain} sidechain
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
          <input
            type="text"
            placeholder="Search by block height or hash..."
            className="pl-10 pr-4 py-2 w-full bg-dark-700 border border-dark-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500/50"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <button
          className="btn btn-outline flex items-center gap-2"
          onClick={() => setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc')}
        >
          <Filter size={16} />
          <span>Sort {sortOrder === 'desc' ? 'Newest First' : 'Oldest First'}</span>
        </button>
      </div>

      <Card>
        {isLoading ? (
          <div className="p-6 flex justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
          </div>
        ) : error ? (
          <div className="p-6 text-center text-error-500">
            Failed to load blocks. Please try again.
          </div>
        ) : sortedBlocks.length === 0 ? (
          <div className="p-6 text-center text-gray-400">
            No blocks found matching your search criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-gray-400 text-sm">
                  <th className="px-4 py-3">Height</th>
                  <th className="px-4 py-3">Hash</th>
                  <th className="px-4 py-3">Age</th>
                  <th className="px-4 py-3">Txs</th>
                  <th className="px-4 py-3">Size</th>
                  <th className="px-4 py-3">Difficulty</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-dark-600">
                {sortedBlocks.map((block) => (
                  <tr
                    key={block.hash}
                    className="hover:bg-dark-700/50 transition-colors"
                  >
                    <td className="px-4 py-3">
                      <Link
                        to={`/explorer/block/${block.hash}`}
                        className="text-primary-500 hover:underline font-medium"
                      >
                        {block.height}
                      </Link>
                    </td>
                    <td className="px-4 py-3">
                      <Link
                        to={`/explorer/block/${block.hash}`}
                        className="text-white hover:text-primary-400 transition-colors font-mono"
                      >
                        {block.hash.substring(0, 8)}...{block.hash.substring(block.hash.length - 8)}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-gray-400">
                      {formatDistance(new Date(block.timestamp), new Date(), { addSuffix: true })}
                    </td>
                    <td className="px-4 py-3 text-gray-400">{block.transactionCount}</td>
                    <td className="px-4 py-3 text-gray-400">{formatBlockSize(block.size)}</td>
                    <td className="px-4 py-3 text-gray-400">{block.difficulty.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
};

export default BlockExplorer;
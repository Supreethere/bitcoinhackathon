import React, { useState } from 'react';
import { useAppStore } from '../stores/appStore';
import { SidechainType } from '../types/sidechain';
import Card from '../components/common/Card';
import { Save, AlertCircle, Check } from 'lucide-react';

const Settings: React.FC = () => {
  const {
    currentSidechain,
    refreshInterval,
    showTestnet,
    networkSettings,
    setRefreshInterval,
    setShowTestnet,
    updateNetworkSettings,
  } = useAppStore();

  const [tempNetworkSettings, setTempNetworkSettings] = useState(networkSettings);
  const [savedMessage, setSavedMessage] = useState('');

  const handleEndpointChange = (
    chain: SidechainType,
    field: 'apiEndpoint' | 'websocketEndpoint' | 'rpcEndpoint',
    value: string
  ) => {
    setTempNetworkSettings((prev) => ({
      ...prev,
      [chain]: {
        ...prev[chain],
        [field]: value,
      },
    }));
  };

  const handleSaveNetworkSettings = () => {
    // Save each chain's settings
    Object.entries(tempNetworkSettings).forEach(([chain, settings]) => {
      updateNetworkSettings(chain as SidechainType, settings);
    });

    // Show saved message
    setSavedMessage('Settings saved successfully!');
    setTimeout(() => setSavedMessage(''), 3000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">Settings</h1>
        <p className="text-gray-400">Configure your sidechain explorer preferences</p>
      </div>

      {savedMessage && (
        <div className="bg-success-500/20 border border-success-500/30 rounded-md p-3 flex items-start">
          <Check className="text-success-500 mr-2 flex-shrink-0 mt-0.5" size={16} />
          <span className="text-success-400">{savedMessage}</span>
        </div>
      )}

      <Card title="Display Settings">
        <div className="p-4 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Refresh Interval (milliseconds)
            </label>
            <select
              value={refreshInterval}
              onChange={(e) => setRefreshInterval(Number(e.target.value))}
              className="w-full bg-dark-700 border border-dark-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500/50"
            >
              <option value={5000}>5 seconds</option>
              <option value={10000}>10 seconds</option>
              <option value={30000}>30 seconds</option>
              <option value={60000}>1 minute</option>
              <option value={300000}>5 minutes</option>
            </select>
          </div>

          <div className="flex items-center">
            <input
              type="checkbox"
              id="showTestnet"
              checked={showTestnet}
              onChange={(e) => setShowTestnet(e.target.checked)}
              className="h-4 w-4 rounded border-dark-500 bg-dark-700 text-primary-500 focus:ring-primary-500/30"
            />
            <label htmlFor="showTestnet" className="ml-2 block text-sm text-gray-400">
              Show testnet networks
            </label>
          </div>
        </div>
      </Card>

      <Card title="Network Endpoints">
        <div className="p-4 space-y-6">
          <div className="p-2 bg-dark-800 rounded-md border border-dark-600 mb-4">
            <div className="flex items-start">
              <AlertCircle size={16} className="text-warning-500 mt-0.5 mr-2 flex-shrink-0" />
              <p className="text-sm text-gray-400">
                These settings are for advanced users. Incorrect endpoints may cause the explorer to malfunction.
                The default endpoints should work for most users.
              </p>
            </div>
          </div>

          {(['thunder', 'zside', 'bitnames'] as const).map((chain) => (
            <div key={chain} className="space-y-3">
              <h3 className="font-medium border-b border-dark-600 pb-2">
                {chain.charAt(0).toUpperCase() + chain.slice(1)} Endpoints
              </h3>

              <div>
                <label className="block text-sm text-gray-400 mb-1">API Endpoint</label>
                <input
                  type="text"
                  value={tempNetworkSettings[chain].apiEndpoint}
                  onChange={(e) => handleEndpointChange(chain, 'apiEndpoint', e.target.value)}
                  className="w-full bg-dark-700 border border-dark-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500/50"
                />
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">WebSocket Endpoint</label>
                <input
                  type="text"
                  value={tempNetworkSettings[chain].websocketEndpoint}
                  onChange={(e) => handleEndpointChange(chain, 'websocketEndpoint', e.target.value)}
                  className="w-full bg-dark-700 border border-dark-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500/50"
                />
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">RPC Endpoint</label>
                <input
                  type="text"
                  value={tempNetworkSettings[chain].rpcEndpoint}
                  onChange={(e) => handleEndpointChange(chain, 'rpcEndpoint', e.target.value)}
                  className="w-full bg-dark-700 border border-dark-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500/50"
                />
              </div>
            </div>
          ))}

          <div className="pt-2">
            <button
              onClick={handleSaveNetworkSettings}
              className="btn btn-primary flex items-center gap-2"
            >
              <Save size={16} />
              <span>Save Settings</span>
            </button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default Settings;
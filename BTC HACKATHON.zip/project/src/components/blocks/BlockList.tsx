import React from 'react';
import { Link } from 'react-router-dom';
import { formatDistance } from 'date-fns';
import { ArrowRight, ChevronRight } from 'lucide-react';
import { Block } from '../../types/sidechain';
import Card from '../common/Card';
import { motion } from 'framer-motion';

interface BlockListProps {
  blocks: Block[];
  loading: boolean;
  title?: string;
  limit?: number;
  showViewAll?: boolean;
}

const BlockList: React.FC<BlockListProps> = ({
  blocks,
  loading,
  title = 'Latest Blocks',
  limit = 5,
  showViewAll = true,
}) => {
  const displayBlocks = blocks.slice(0, limit);

  const formatBlockSize = (size: number): string => {
    if (size < 1000) return `${size} B`;
    if (size < 1000000) return `${(size / 1000).toFixed(1)} KB`;
    return `${(size / 1000000).toFixed(1)} MB`;
  };

  if (loading) {
    return (
      <Card title={title}>
        <div className="space-y-4">
          {Array.from({ length: limit }).map((_, index) => (
            <div key={index} className="p-3 border-b border-dark-600 last:border-0">
              <div className="flex justify-between">
                <div className="w-24 h-5 bg-dark-600 rounded animate-pulse"></div>
                <div className="w-36 h-5 bg-dark-600 rounded animate-pulse"></div>
              </div>
              <div className="mt-2 flex justify-between">
                <div className="w-40 h-4 bg-dark-600 rounded animate-pulse"></div>
                <div className="w-20 h-4 bg-dark-600 rounded animate-pulse"></div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    );
  }

  return (
    <Card 
      title={title}
      actions={
        showViewAll && (
          <Link 
            to="/explorer" 
            className="flex items-center text-xs text-primary-400 hover:text-primary-300"
          >
            View All <ChevronRight size={14} />
          </Link>
        )
      }
    >
      <div className="divide-y divide-dark-600">
        {displayBlocks.map((block, index) => (
          <motion.div 
            key={block.hash}
            className="p-3 hover:bg-dark-700/50 transition-colors"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2, delay: index * 0.05 }}
          >
            <Link to={`/explorer/block/${block.hash}`} className="block">
              <div className="flex justify-between items-start">
                <div className="flex items-center">
                  <div className="flex items-center bg-dark-800 rounded-md px-2 py-1">
                    <span className="text-primary-500 font-medium">{block.height}</span>
                  </div>
                  <ArrowRight size={14} className="mx-2 text-gray-500" />
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-white truncate max-w-[120px] md:max-w-[200px]">
                      {block.hash.substring(0, 8)}...{block.hash.substring(block.hash.length - 8)}
                    </span>
                    <span className="text-xs text-gray-400">
                      {formatDistance(new Date(block.timestamp), new Date(), { addSuffix: true })}
                    </span>
                  </div>
                </div>
                <div className="flex flex-col items-end text-xs">
                  <span className="text-gray-400">
                    {block.transactionCount} txs
                  </span>
                  <span className="text-gray-400">
                    {formatBlockSize(block.size)}
                  </span>
                </div>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </Card>
  );
};

export default BlockList;
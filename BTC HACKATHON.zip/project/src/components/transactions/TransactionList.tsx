import React from 'react';
import { Link } from 'react-router-dom';
import { formatDistance } from 'date-fns';
import { ArrowRight, ChevronRight } from 'lucide-react';
import { Transaction } from '../../types/sidechain';
import Card from '../common/Card';
import { motion } from 'framer-motion';

interface TransactionListProps {
  transactions: Transaction[];
  loading: boolean;
  title?: string;
  limit?: number;
  showViewAll?: boolean;
}

const TransactionList: React.FC<TransactionListProps> = ({
  transactions,
  loading,
  title = 'Latest Transactions',
  limit = 5,
  showViewAll = true,
}) => {
  const displayTransactions = transactions.slice(0, limit);

  if (loading) {
    return (
      <Card title={title}>
        <div className="space-y-4">
          {Array.from({ length: limit }).map((_, index) => (
            <div key={index} className="p-3 border-b border-dark-600 last:border-0">
              <div className="flex justify-between">
                <div className="w-44 h-5 bg-dark-600 rounded animate-pulse"></div>
                <div className="w-20 h-5 bg-dark-600 rounded animate-pulse"></div>
              </div>
              <div className="mt-2 flex justify-between">
                <div className="w-32 h-4 bg-dark-600 rounded animate-pulse"></div>
                <div className="w-16 h-4 bg-dark-600 rounded animate-pulse"></div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    );
  }

  return (
    <Card 
      title={title}
      actions={
        showViewAll && (
          <Link 
            to="/transactions" 
            className="flex items-center text-xs text-primary-400 hover:text-primary-300"
          >
            View All <ChevronRight size={14} />
          </Link>
        )
      }
    >
      <div className="divide-y divide-dark-600">
        {displayTransactions.map((tx, index) => (
          <motion.div 
            key={tx.txid}
            className="p-3 hover:bg-dark-700/50 transition-colors"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2, delay: index * 0.05 }}
          >
            <Link to={`/transactions/${tx.txid}`} className="block">
              <div className="flex justify-between items-start">
                <div className="flex flex-col">
                  <div className="flex items-center">
                    <span className="text-sm font-medium text-white truncate max-w-[150px] md:max-w-[250px]">
                      {tx.txid.substring(0, 8)}...{tx.txid.substring(tx.txid.length - 8)}
                    </span>
                    {tx.isCoinbase && (
                      <span className="ml-2 badge badge-primary">Coinbase</span>
                    )}
                  </div>
                  <span className="text-xs text-gray-400">
                    {formatDistance(new Date(tx.timestamp), new Date(), { addSuffix: true })}
                  </span>
                </div>
                <div className="flex flex-col items-end">
                  <span className="text-sm font-medium text-white">
                    {tx.fee.toFixed(8)} BTC
                  </span>
                  <span className="text-xs text-gray-400">
                    {tx.confirmations === 0 ? 'Unconfirmed' : `${tx.confirmations} confirmations`}
                  </span>
                </div>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </Card>
  );
};

export default TransactionList;
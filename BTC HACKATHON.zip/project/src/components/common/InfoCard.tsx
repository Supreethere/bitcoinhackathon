import React from 'react';
import { motion } from 'framer-motion';
import { HelpCircle } from 'lucide-react';

interface InfoCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: React.ReactNode;
  change?: number;
  tooltip?: string;
  loading?: boolean;
  className?: string;
}

const InfoCard: React.FC<InfoCardProps> = ({
  title,
  value,
  subtitle,
  icon,
  change,
  tooltip,
  loading = false,
  className = '',
}) => {
  return (
    <motion.div
      className={`card p-4 ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex justify-between items-start mb-2">
        <div className="flex items-center space-x-1">
          <h3 className="text-sm text-gray-400 font-medium">{title}</h3>
          {tooltip && (
            <div className="tooltip">
              <HelpCircle size={14} className="text-gray-500" />
              <span className="tooltip-text">{tooltip}</span>
            </div>
          )}
        </div>
        {icon && <div className="text-primary-500">{icon}</div>}
      </div>

      {loading ? (
        <div className="h-8 bg-dark-600 rounded animate-pulse"></div>
      ) : (
        <div className="flex items-end space-x-2">
          <h2 className="text-2xl font-bold text-white">{value}</h2>
          {change !== undefined && (
            <span
              className={`text-xs font-medium ${
                change >= 0 ? 'text-success-500' : 'text-error-500'
              }`}
            >
              {change >= 0 ? '+' : ''}
              {change}%
            </span>
          )}
        </div>
      )}

      {subtitle && <div className="text-xs text-gray-400 mt-1">{subtitle}</div>}
    </motion.div>
  );
};

export default InfoCard;
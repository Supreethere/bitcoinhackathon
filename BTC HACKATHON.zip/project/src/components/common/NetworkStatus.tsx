import React, { useState, useEffect } from 'react';
import { Wifi, WifiOff, AlertTriangle } from 'lucide-react';
import { useAppStore } from '../../stores/appStore';
import { bip300Api } from '../../services/api';
import { SidechainInfo } from '../../types/sidechain';

const NetworkStatus: React.FC = () => {
  const { isConnected, currentSidechain } = useAppStore();
  const [sidechainStatus, setSidechainStatus] = useState<'online' | 'offline' | 'warning'>('offline');
  const [tooltipVisible, setTooltipVisible] = useState(false);
  const [info, setInfo] = useState<SidechainInfo | null>(null);

  useEffect(() => {
    if (isConnected) {
      const fetchSidechainStatus = async () => {
        try {
          const info = await bip300Api.getSidechainInfo(currentSidechain);
          setSidechainStatus(info.status);
          setInfo(info);
        } catch (error) {
          setSidechainStatus('offline');
        }
      };

      fetchSidechainStatus();
      const interval = setInterval(fetchSidechainStatus, 30000); // Update every 30 seconds
      
      return () => {
        clearInterval(interval);
      };
    } else {
      setSidechainStatus('offline');
    }
  }, [isConnected, currentSidechain]);

  const getStatusIcon = () => {
    if (!isConnected) return <WifiOff size={18} className="text-error-500" />;
    
    switch (sidechainStatus) {
      case 'online':
        return <Wifi size={18} className="text-success-500" />;
      case 'warning':
        return <AlertTriangle size={18} className="text-warning-500" />;
      case 'offline':
      default:
        return <WifiOff size={18} className="text-error-500" />;
    }
  };

  const getStatusText = () => {
    if (!isConnected) return 'No Connection';
    
    switch (sidechainStatus) {
      case 'online':
        return `${info?.name || currentSidechain} Online`;
      case 'warning':
        return `${info?.name || currentSidechain} Issues`;
      case 'offline':
      default:
        return `${info?.name || currentSidechain} Offline`;
    }
  };

  const getStatusColor = () => {
    if (!isConnected) return 'bg-error-500/20 text-error-400';
    
    switch (sidechainStatus) {
      case 'online':
        return 'bg-success-500/20 text-success-400';
      case 'warning':
        return 'bg-warning-500/20 text-warning-400';
      case 'offline':
      default:
        return 'bg-error-500/20 text-error-400';
    }
  };

  return (
    <div 
      className="tooltip"
      onMouseEnter={() => setTooltipVisible(true)}
      onMouseLeave={() => setTooltipVisible(false)}
    >
      <div className={`flex items-center space-x-2 px-3 py-1.5 rounded-full ${getStatusColor()}`}>
        {getStatusIcon()}
        <span className="text-xs font-medium hidden md:inline">{getStatusText()}</span>
      </div>
      
      {tooltipVisible && (
        <div className="tooltip-text">
          <div className="font-medium">{getStatusText()}</div>
          {info && (
            <div className="mt-1 text-xs text-gray-300">
              <div>Height: {info.blockHeight}</div>
              <div>TPS: {info.tps}</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default NetworkStatus;
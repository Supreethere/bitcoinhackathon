import React from 'react';
import { motion } from 'framer-motion';

interface CardProps {
  title?: string;
  children: React.ReactNode;
  className?: string;
  actions?: React.ReactNode;
  glass?: boolean;
  delay?: number;
}

const Card: React.FC<CardProps> = ({ 
  title, 
  children, 
  className = '', 
  actions,
  glass = false,
  delay = 0
}) => {
  return (
    <motion.div
      className={`${glass ? 'card-glass' : 'card'} ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: delay * 0.1 }}
    >
      {title && (
        <div className="flex justify-between items-center px-4 py-3 border-b border-dark-600">
          <h3 className="font-medium text-white">{title}</h3>
          {actions && <div>{actions}</div>}
        </div>
      )}
      <div className={!title ? 'p-4' : ''}>{children}</div>
    </motion.div>
  );
};

export default Card;
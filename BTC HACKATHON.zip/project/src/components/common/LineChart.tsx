import React, { useState } from 'react';
import {
  ResponsiveContainer,
  LineChart as RechartsLineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { format } from 'date-fns';
import { ChartData } from '../../types/sidechain';

interface LineChartProps {
  data: ChartData;
  height?: number;
  showGrid?: boolean;
  showLegend?: boolean;
  tooltipFormatter?: (value: number) => string;
}

const LineChart: React.FC<LineChartProps> = ({
  data,
  height = 300,
  showGrid = true,
  showLegend = true,
  tooltipFormatter,
}) => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const formattedData = data.data.map((point, index) => ({
    timestamp: point.timestamp,
    value: point.value,
    date: format(new Date(point.timestamp), 'MMM dd'),
    time: format(new Date(point.timestamp), 'HH:mm'),
    index,
  }));

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const dataPoint = payload[0].payload;
      const value = tooltipFormatter 
        ? tooltipFormatter(dataPoint.value) 
        : dataPoint.value;

      return (
        <div className="bg-dark-900 p-2 rounded border border-dark-600 shadow-lg">
          <p className="text-xs text-gray-400">{dataPoint.date}, {dataPoint.time}</p>
          <p className="text-sm font-medium text-white">
            {data.label}: <span className="text-primary-500">{value}</span>
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full h-full">
      <ResponsiveContainer width="100%" height={height}>
        <RechartsLineChart
          data={formattedData}
          margin={{ top: 10, right: 10, left: 10, bottom: 5 }}
          onMouseMove={(e) => {
            if (e.activeTooltipIndex !== undefined) {
              setActiveIndex(e.activeTooltipIndex);
            }
          }}
          onMouseLeave={() => setActiveIndex(null)}
        >
          {showGrid && (
            <CartesianGrid
              strokeDasharray="3 3"
              vertical={false}
              stroke="#2D2D3A"
            />
          )}
          <XAxis
            dataKey="date"
            axisLine={false}
            tickLine={false}
            tick={{ fill: '#8D8D9D', fontSize: 12 }}
            minTickGap={20}
          />
          <YAxis
            axisLine={false}
            tickLine={false}
            tick={{ fill: '#8D8D9D', fontSize: 12 }}
            width={40}
          />
          <Tooltip content={<CustomTooltip />} />
          {showLegend && (
            <Legend
              wrapperStyle={{ bottom: 0 }}
              formatter={(value) => (
                <span className="text-sm text-gray-400">{value}</span>
              )}
            />
          )}
          <Line
            type="monotone"
            dataKey="value"
            name={data.label}
            stroke="#F68216"
            strokeWidth={2}
            dot={false}
            activeDot={{ r: 6, fill: '#F68216', stroke: '#1E1E2A', strokeWidth: 2 }}
          />
        </RechartsLineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default LineChart;
import React, { useState } from 'react';
import { ChevronDown, Zap, Lock, FileText } from 'lucide-react';
import { useAppStore } from '../../stores/appStore';
import { SidechainType } from '../../types/sidechain';
import { motion, AnimatePresence } from 'framer-motion';

const SidechainSelector: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { currentSidechain, setCurrentSidechain } = useAppStore();

  const sidechains = [
    { id: 'thunder', label: 'Thunder', icon: <Zap size={16} className="text-primary-500" />, description: 'High-throughput sidechain' },
    { id: 'zside', label: 'zSide', icon: <Lock size={16} className="text-secondary-500" />, description: 'Privacy-focused sidechain' },
    { id: 'bitnames', label: 'BitNames', icon: <FileText size={16} className="text-accent-500" />, description: 'Decentralized naming' },
  ];

  const currentChain = sidechains.find(chain => chain.id === currentSidechain);

  const handleSelect = (chain: SidechainType) => {
    setCurrentSidechain(chain);
    setIsOpen(false);
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between px-3 py-2 rounded bg-dark-700 hover:bg-dark-600 border border-dark-600 transition-colors"
      >
        <div className="flex items-center">
          {currentChain?.icon}
          <span className="ml-2 font-medium">{currentChain?.label}</span>
        </div>
        <ChevronDown size={16} className={`transform transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.15 }}
            className="absolute top-full left-0 right-0 mt-1 z-10 bg-dark-700 border border-dark-600 rounded-md shadow-lg overflow-hidden"
          >
            <div className="p-1">
              {sidechains.map((chain) => (
                <button
                  key={chain.id}
                  onClick={() => handleSelect(chain.id as SidechainType)}
                  className={`w-full text-left px-3 py-2 rounded flex items-start transition-colors ${
                    currentSidechain === chain.id
                      ? 'bg-dark-600'
                      : 'hover:bg-dark-600'
                  }`}
                >
                  <div className="flex items-center">
                    <span className="mr-2">{chain.icon}</span>
                    <div>
                      <div className="font-medium">{chain.label}</div>
                      <div className="text-xs text-gray-400">{chain.description}</div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SidechainSelector;
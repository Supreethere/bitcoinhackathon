import React from 'react';
import { Search, Bell, Menu, X } from 'lucide-react';
import { useAppStore } from '../../stores/appStore';
import NetworkStatus from '../common/NetworkStatus';
import { motion } from 'framer-motion';

interface HeaderProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

const Header: React.FC<HeaderProps> = ({ sidebarOpen, setSidebarOpen }) => {
  const { isConnected, currentSidechain } = useAppStore();

  return (
    <header className="bg-dark-800 border-b border-dark-600 h-16 flex items-center px-4 sticky top-0 z-20">
      <div className="flex-1 flex items-center">
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="p-2 rounded-md text-gray-400 hover:text-white hover:bg-dark-700 lg:hidden"
        >
          {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
        
        <div className="relative ml-4 lg:w-64">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <Search size={16} className="text-gray-400" />
          </div>
          <input
            type="text"
            className="bg-dark-700 text-sm text-white rounded-md pl-10 pr-4 py-2 w-full focus:outline-none focus:ring-1 focus:ring-primary-500/50 border border-dark-600"
            placeholder="Search blocks, txs, addresses..."
          />
        </div>
      </div>
      
      <div className="flex items-center space-x-4">
        <NetworkStatus />
        
        <div className="relative">
          <Bell size={20} className="text-gray-400 hover:text-white cursor-pointer" />
          <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary-500 text-[10px] font-bold text-white">
            3
          </span>
        </div>
        
        <motion.div 
          className="hidden md:flex items-center space-x-2 bg-dark-700 px-3 py-1.5 rounded-full border border-dark-600"
          initial={{ opacity: 0, x: 10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className={`h-2 w-2 rounded-full ${isConnected ? 'bg-success-500' : 'bg-error-500'}`} />
          <span className="text-xs font-medium">
            {currentSidechain.charAt(0).toUpperCase() + currentSidechain.slice(1)}
          </span>
        </motion.div>
      </div>
    </header>
  );
};

export default Header;